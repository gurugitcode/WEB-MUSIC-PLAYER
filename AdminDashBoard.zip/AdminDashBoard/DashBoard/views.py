from django.shortcuts import render,HttpResponseRedirect
from django.views import View
from django.contrib.auth.models import User ,Group
from django.contrib.auth import logout,login,authenticate
from .forms import UserCreateforms,LoginForm,VideoForm
from django.contrib import messages
from .models import ModelUpVideo
from django.http import JsonResponse

# Create your views here.
class Home(View):
    tamplate_name = "home.html"
    def get(self,request):
        return render(request,self.tamplate_name)
    def post(self,request):
        return render(request,self.tamplate_name)

class DashBoard(View):
    tamplate_name = "DashBoard.html"
    def get(self,request):
        if request.user.is_authenticated:
            return render(request,self.tamplate_name)
        else:
            return HttpResponseRedirect('/mp3/login')

    def post(self,request):
        if request.user.is_authenticated:
            return render(request,self.tamplate_name)
        else:
            return HttpResponseRedirect('/mp3/login')

class CreateAccount(View):
    tamplate_name = "sign_up.html"
    def get(self,request):
        fm=UserCreateforms()
        return render(request,self.tamplate_name,{"form":fm})
    def post(self,request):
        if request.method=='POST':
            fm=UserCreateforms(request.POST)
            if fm.is_valid():
                messages.success(request, "Congratulations Your account created")
                user=fm.save()
                # group created
                group = Group.objects.get_or_create(name="Author")
                group = Group.objects.get(name='Author')
                user.groups.add(group)
                fm =UserCreateforms()
        else:
            fm=UserCreateforms()

        return render(request,self.tamplate_name,{'form':fm})

class UserLogin(View):
    template_name="login.html"
    def get(self,request):
        fm=LoginForm()
        return render(request, self.template_name,{'form':fm})

    def post(self,request):
        if request.method=='POST':
            fm = LoginForm(request=request,data=request.POST)
            if fm.is_valid():
                uname = fm.cleaned_data['username']
                upass = fm.cleaned_data['password']
                user = authenticate(username=uname,password=upass)
                if user is not None:
                    login(request,user)
                    group = Group.objects.get(name='Author')
                    users = group.user_set.all()
                    messages.success(request,'Login in Successfuly')
                    return HttpResponseRedirect('/playmp3/mp3')

        else:
            fm=LoginForm()
        return render(request, self.template_name,{'form':fm})

# Logout_User
class User_logout(View):
    def get(self,request):
        if request.user.is_authenticated:
            logout(request)
            return HttpResponseRedirect('/mp3/login')
        else:
            return HttpResponseRedirect('/mp3/login')
class player(View):
    template_name='playermp3.html'
    def get(self,request):
        if request.user.is_authenticated:
            videos =ModelUpVideo.objects.order_by('?')
            return render(request,self.template_name,{'data':videos})
        else:
            return HttpResponseRedirect('/mp3/login')


class UplodeVideo(View):
    template_name='midia_data.html'
    def get(self,request):
        if request.user.is_authenticated:
            form=VideoForm()
            return render(request,self.template_name,{'form':form})
        else:
            return HttpResponseRedirect('/mp3/login')


    def post(self,request):
        if request.user.is_authenticated:
            if request.method=='POST':
                lastvideo= ModelUpVideo.objects.all()
                form= VideoForm(request.POST or None, request.FILES or None)
                if form.is_valid():
                    user=request.user
                    title=form.cleaned_data['name']
                    video=form.cleaned_data['videofile']
                    reg=ModelUpVideo(user=user,name=title,videofile=video)
                    reg.save()
                    messages.success(request,'Successfully Your video uploded.')
                    form=VideoForm()
                    return HttpResponseRedirect('/mp3/mp3')
            else:
                form=VideoForm()
            return render(request,self.template_name,{'form':form})
        else:
                return HttpResponseRedirect('/mp3/login')


class Play_Song(View):
    template_name='mp3.html'
    def get(self,request):
        return JsonResponse({"status":0})
    
    def post(self,request):
        if request.method=="POST":
            id = request.POST.get("sid")
            print(id)
            student_data = ModelUpVideo.objects.get(pk=id)
            print(student_data)
            # student_data={"id":student.id,"name":student.name}
            # print(student_data)  
            return JsonResponse(student_data)
        else:
            return JsonResponse({"status":0})

    # def get(self,request,id):
    #     if request.user.is_authenticated:
    #         data = ModelUpVideo.objects.get(pk=id)
    #         return render(request,self.template_name,{'data':data})
            
    #     else:
    #         return HttpResponseRedirect('/mp3/login')
