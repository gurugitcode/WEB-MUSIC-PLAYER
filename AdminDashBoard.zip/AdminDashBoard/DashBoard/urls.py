from django.urls import path
from . import  views

urlpatterns = [
    path('',views.Home.as_view(),name='home'),
    path('dashboard/',views.DashBoard.as_view(),name='DashBoard'),
    path('createaccount/',views.CreateAccount.as_view(),name='CreateAccount'),
    path('login/',views.UserLogin.as_view(),name='login'),
    path('login/',views.User_logout.as_view(),name='logout'),
    path('media/',views.UplodeVideo.as_view(),name='media'),
    path('mp3/',views.player.as_view(),name='mp3'),
    path('mp3p/',views.Play_Song.as_view(),name='play_mp3'),



]