from django.contrib import admin
from .models import ModelUpVideo
# Register your models here.

@admin.register(ModelUpVideo)
class Adminmedia(admin.ModelAdmin):
    list_display = ['user','name','videofile']